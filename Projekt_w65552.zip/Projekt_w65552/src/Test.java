import static org.junit.Assert.*;

public class Test {

    @org.junit.Test
    public void usunPracownika() {
    }
    @org.junit.Test
    public void dodajPracownika() {
    }
    @org.junit.Test
    public void StworzPizza() {
    }
    @org.junit.Test
    public void RozliczenieParagonu() {
    }
    @org.junit.Test
    public void Zamowienia() {
    }
    @org.junit.Test
    public void Zamowienie() {
    }
    @org.junit.Test
    public void KartaKlienta() {
    }@org.junit.Test
    public void wyswietlMenu() {
    }@org.junit.Test
    public void Pizzeria() {
    }





}